package noticeServlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import exAdmin.util.PageIndex;
import notice.model.NoticeDAO;
import notice.model.NoticeVO;

/**
 * Servlet implementation class noticeListServlet
 */
@WebServlet("/notice_list.do")
public class noticeListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public noticeListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		NoticeDAO DAO = NoticeDAO.getInstance();
		String sql = "", search = "",key="";
		int totcount = 0; //�Խñ� �� ��
		
		//�˻��� �������
		if(request.getParameter("key") != null) {
			key = request.getParameter("key");
			search = request.getParameter("search");
			sql = search + " like '%" + key + "%'";
			totcount = DAO.noticeCount(sql);
		}
		//�˻��� �������
		else {
			totcount = DAO.noticeCount();
		}
		
		int nowpage = 1;
		int maxlist = 10;
		int totpage = 1;
		
		//���������� ���
		if(totcount % maxlist == 0) {
			totpage = totcount / maxlist;
		}
		else {
			totpage = (totcount / maxlist) + 1;
		}
		
		//��������ȣ�� �Էµ� ���
		if(request.getParameter("page") != null) {
			nowpage = Integer.parseInt(request.getParameter("page"));
		}
		
		int startpage = (nowpage-1)*maxlist + 1;
		int endpage = nowpage * maxlist;
		int listcount = totcount -(nowpage-1)*maxlist;
		
		List<NoticeVO> list = null;
		if(key.equals("")) {
			list = DAO.noticeList(startpage, endpage);
		}
		else {
			list = DAO.noticeList(startpage,endpage,sql);
		}
		
		String pageSkip = "";
		if(key.equals("")) {
			pageSkip = PageIndex.pageList(nowpage, totpage, "notice_list.do", "");
		}
		else {
			pageSkip = PageIndex.pageListHan(nowpage, totpage, "notice_list.do", search, key);
		}
		
		request.setAttribute("page", nowpage);
		request.setAttribute("totcount", totcount);
		request.setAttribute("listcount", listcount);
		request.setAttribute("totpage", totpage);
		request.setAttribute("list", list);
		request.setAttribute("pageSkip", pageSkip);
		request.setAttribute("search", search);
		request.setAttribute("key", key);
		
		
		RequestDispatcher rd = request.getRequestDispatcher("Admin/notice_list.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
