package exAdmin.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exAdmin.model.AdminDAO;
import exAdmin.model.AdminVO;



/**
 * Servlet implementation class adminListServlet
 */
@WebServlet("/admin_list.do")
public class adminListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public adminListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = request.getRequestDispatcher("Admin/admin.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String adminid = request.getParameter("adminid");
		String adminpass = request.getParameter("adminpass");
		AdminDAO DAO = AdminDAO.getInstance();
		HttpSession session = request.getSession();
		AdminVO admin = DAO.adminselet(adminid);
		session.setMaxInactiveInterval(1800);
		session.setAttribute("admin", admin);
		RequestDispatcher rd = request.getRequestDispatcher("Admin/admin.jsp");
		rd.forward(request, response);
	}

}
