package com.jslhrd.controller.user;

import com.jslhrd.service.Action;
import com.jslhrd.service.user.UserDeleteAction;
import com.jslhrd.service.user.UserIdCheckAction;
import com.jslhrd.service.user.UserInsertAction;
import com.jslhrd.service.user.UserInsertProAction;
import com.jslhrd.service.user.UserListAction;
import com.jslhrd.service.user.UserLoginAction;
import com.jslhrd.service.user.UserLoginProAction;
import com.jslhrd.service.user.UserLogoutAction;
import com.jslhrd.service.user.UserModifyAction;
import com.jslhrd.service.user.UserModifyProAction;

public class UserActionFactory {
private static UserActionFactory instance = new UserActionFactory();
	
	private UserActionFactory() {
		
	}
	
	public static UserActionFactory getInstance() {
		return instance;
	}
	
	public Action getAction(String cmd) {
		Action action = null;
		System.out.println("UserActionFactory : " + cmd);
		if(cmd.equals("user_login")) {
			action = new UserLoginAction();
		}
		else if(cmd.equals("user_insert")) {
			action = new UserInsertAction();
		}
		else if(cmd.equals("user_write_pro")) {
			action = new UserInsertProAction();
		}
		else if(cmd.equals("user_idcheck")) {
			action = new UserIdCheckAction();
		}
		else if(cmd.equals("user_login_pro")) {
			action = new UserLoginProAction();
		}
		else if(cmd.equals("user_logout")) {
			action = new UserLogoutAction();
		}
		else if(cmd.equals("user_modify")) {
			action = new UserModifyAction();
		}
		else if(cmd.equals("user_modify_pro")) {
			action = new UserModifyProAction();
		}
		else if(cmd.equals("user_delete")) {
			action = new UserDeleteAction();
		}
		else if(cmd.equals("user_list")) {
			action = new UserListAction();
		}
		return action;
	}
}
