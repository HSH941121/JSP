package com.jslhrd.service.user;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jslhrd.domain.user.UsersDAO;
import com.jslhrd.domain.user.UsersVO;
import com.jslhrd.service.Action;
import com.jslhrd.util.SHA256Util;

public class UserInsertProAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		UsersDAO DAO = UsersDAO.getInstance();
		UsersVO vo = new UsersVO();
		String email = "";
		String email1 = request.getParameter("email1");
		String email2 = request.getParameter("email2");
		email = email1 + "@" + email2;
		vo.setName(request.getParameter("name"));
		vo.setUserid(request.getParameter("userid"));
		vo.setPasswd(SHA256Util.getEncSHA256(request.getParameter("passwd")));
		vo.setTel(request.getParameter("tel"));
		vo.setEmail(email);
		int row = DAO.userInsert(vo);
		request.setAttribute("row", row);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/Users/user_insert_pro.jsp");
		dispatcher.forward(request, response);
	}

}
