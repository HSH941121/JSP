package com.jslhrd.service.user;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jslhrd.domain.user.UsersDAO;
import com.jslhrd.domain.user.UsersVO;
import com.jslhrd.service.Action;

public class UserDeleteAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		UsersDAO DAO = UsersDAO.getInstance();
		UsersVO vo = new UsersVO();
		HttpSession session = request.getSession();
		vo = (UsersVO)session.getAttribute("user");
		String userid = vo.getUserid();
		int row = DAO.userDelete(userid);
		session.invalidate();
		
		RequestDispatcher rd = request.getRequestDispatcher("Users/user_delete_pro.jsp");
		rd.forward(request, response);
	}

}
