package com.jslhrd.service.pds;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jslhrd.domain.pds.PdsDAO;
import com.jslhrd.domain.pds.PdsVO;
import com.jslhrd.service.Action;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class PdsWriteProAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		ServletContext context = request.getSession().getServletContext();

		//��ó: https://chogoon.tistory.com/entry/Java-����-getServletContext-��-��� [�ʱ��н���]
		//���� ���� ���
		String path = context.getRealPath("Pds/upload");
		String encType = "utf-8";
		int sizeLimit = 2*1024*1024; //���� �ִ� �뷮 ����
		
		MultipartRequest multi = new MultipartRequest(request,path,sizeLimit,encType, new DefaultFileRenamePolicy());
		//���� �ߺ��� �ڵ� �̸� ����
		
		PdsVO vo = new PdsVO();
		vo.setName(multi.getParameter("name"));
		vo.setEmail(multi.getParameter("email"));
		vo.setSubject(multi.getParameter("subject"));
		vo.setContetns(multi.getParameter("contents"));
		vo.setPass(multi.getParameter("pass"));
		vo.setFilename(multi.getFilesystemName("filename"));
		
		PdsDAO DAO = PdsDAO.getInstance();
		
		int page = Integer.parseInt(multi.getParameter("page"));
		int row = DAO.pdsWrite(vo);
		
		request.setAttribute("row", row);
		request.setAttribute("page", page);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/Pds/pds_write_pro.jsp");
		dispatcher.forward(request, response);
	}

}
