package com.jslhrd.service.pds;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jslhrd.domain.pds.PdsDAO;
import com.jslhrd.service.Action;

public class PdsDeleteProAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int idx = Integer.parseInt(request.getParameter("idx"));
		int page = Integer.parseInt(request.getParameter("page"));
		String pass = request.getParameter("pass");
		PdsDAO DAO = PdsDAO.getInstance();
		String filename = DAO.getFilename(idx);
		int row = DAO.pdsDelete(idx, pass);
		
		if(row == 1) {
			ServletContext context = request.getSession().getServletContext();
			//���� ���� ���
			String path = context.getRealPath("Pds/upload/");
			File file = new File(path+filename);
			if(file.exists()) {
				file.delete();
			}
		}
		
		request.setAttribute("row", row);
		request.setAttribute("page", page);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/Pds/pds_delete_pro.jsp");
		dispatcher.forward(request, response);

	}

}
