package com.jslhrd.service.pds;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jslhrd.domain.pds.PdsDAO;
import com.jslhrd.domain.pds.PdsVO;
import com.jslhrd.service.Action;

public class PdsViewAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PdsDAO DAO = PdsDAO.getInstance();
		PdsVO vo = new PdsVO();
		int idx = Integer.parseInt(request.getParameter("idx"));
		int page = Integer.parseInt(request.getParameter("page"));
		vo = DAO.pdsSelect(idx);
		
		boolean bool = false;
		Cookie info = null;
		Cookie[] cookies = request.getCookies();
		for(int i = 0; i < cookies.length; i++) {
			info = cookies[i];
			if(info.getName().equals("Pds" + idx)) {
				bool = true;
				break;
			}
		}
		
		String newValue = "" + System.currentTimeMillis();
		if(!bool) {
			DAO.pdsHits(idx); //��ȸ�� ����
			info = new Cookie("Pds" + idx,newValue);
			info.setMaxAge(60*60);
			response.addCookie(info);
		}
		
		request.setAttribute("pds", vo);
		request.setAttribute("page", page);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/Pds/pds_view.jsp");
		dispatcher.forward(request, response);
	}

	

}
