package com.jslhrd.service.guest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jslhrd.domain.guest.GuestDAO;
import com.jslhrd.domain.guest.GuestVO;
import com.jslhrd.service.Action;

public class GuestModifyAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		GuestDAO dao = GuestDAO.getInstance();
		
		int idx = Integer.parseInt(request.getParameter("idx"));
		int page = Integer.parseInt(request.getParameter("page"));
		
		GuestVO vo = dao.guestSelect(idx);
		
		request.setAttribute("page", page);
		request.setAttribute("guest", vo);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/Guest/guest_modify.jsp");
		dispatcher.forward(request, response);
	}

}
