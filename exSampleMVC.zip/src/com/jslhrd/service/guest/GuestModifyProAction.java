package com.jslhrd.service.guest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jslhrd.domain.guest.GuestDAO;
import com.jslhrd.domain.guest.GuestVO;
import com.jslhrd.service.Action;

public class GuestModifyProAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		GuestVO guest = new GuestVO();
		GuestDAO dao = GuestDAO.getInstance();
		guest.setIdx(Integer.parseInt(request.getParameter("idx")));
		guest.setPass(request.getParameter("pass"));
		guest.setSubject(request.getParameter("subject"));
		guest.setContents(request.getParameter("contents"));
		int page = Integer.parseInt(request.getParameter("page"));
		
		int row = dao.guestModify(guest);
		request.setAttribute("page", page);
		request.setAttribute("row", row);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/Guest/guest_modify_pro.jsp");
		dispatcher.forward(request, response);
	}

}
