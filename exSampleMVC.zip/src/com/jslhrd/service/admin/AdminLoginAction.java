package com.jslhrd.service.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jslhrd.domain.admin.AdminDAO;
import com.jslhrd.domain.admin.AdminVO;
import com.jslhrd.service.Action;

public class AdminLoginAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String adminid = request.getParameter("adminid");
		String adminpass = request.getParameter("adminpass");
		AdminDAO DAO = AdminDAO.getInstance();
		HttpSession session = request.getSession();
		AdminVO admin = DAO.adminselet(adminid);
		session.setMaxInactiveInterval(1800);
		session.setAttribute("admin", admin);
		RequestDispatcher rd = request.getRequestDispatcher("Admin/admin.jsp");
		rd.forward(request, response);
	}

}
