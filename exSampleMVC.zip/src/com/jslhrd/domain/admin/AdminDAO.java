package com.jslhrd.domain.admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.jslhrd.util.DBManager;




public class AdminDAO {
private AdminDAO() {
		
	}
	
	private static AdminDAO instance = new AdminDAO();
	
	public static AdminDAO getInstance() {
		return instance;
	}
	
	
	public AdminVO adminselet(String adminid) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AdminVO vo = new AdminVO();
		int row = 0;
		String sql = "select * from tbl_admin where adminid = ?";
		
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, adminid);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				vo.setAdminid(rs.getString("adminid"));
				vo.setAdminpass(rs.getString("adminpass"));
				vo.setIdx(rs.getInt("idx"));
				vo.setRegdate(rs.getString("regdate"));
				vo.setRate(rs.getInt("rate"));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				DBManager.close(conn, pstmt, rs);
			}
			catch(Exception e) {
				e.printStackTrace();
				
			}
		}
		
		return vo;
	}

}
