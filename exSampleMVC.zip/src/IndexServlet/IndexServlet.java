package IndexServlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jslhrd.domain.board.BoardDAO;
import com.jslhrd.domain.board.BoardVO;
import com.jslhrd.domain.notice.NoticeDAO;
import com.jslhrd.domain.notice.NoticeVO;
import com.jslhrd.domain.pds.PdsDAO;
import com.jslhrd.domain.pds.PdsVO;

/**
 * Servlet implementation class IndexServlet
 */
@WebServlet("/index")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IndexServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		NoticeDAO DAO = NoticeDAO.getInstance();
		BoardDAO DAO2 = BoardDAO.getInstance();
		PdsDAO DAO3 = PdsDAO.getInstance();
		List<NoticeVO> list1 = new ArrayList<NoticeVO>();
		List<BoardVO> list2 = new ArrayList<BoardVO>();
		List<PdsVO> list3 = new ArrayList<PdsVO>();
		list1 = DAO.noticeRecent();
		list2 = DAO2.boardRecent();
		list3 = DAO3.pdsRecent();
		request.setAttribute("notice", list1);
		request.setAttribute("board", list2);
		request.setAttribute("pds", list3);
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
